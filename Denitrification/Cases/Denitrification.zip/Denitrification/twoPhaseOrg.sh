#!/bin/bash
#SBATCH --job-name=NO3-2P-Crs
#SBATCH --mail-user=amir.golparvar@ufz.de
#SBATCH --mail-type=ALL
#SBATCH --time=0-120:00:00
#SBATCH --mem-per-cpu=1G
#SBATCH -n 6
#SBATCH -o BentNO32PCoarse.out
##$ -l cpu_model=E5-2690v4
module load foss/2018a
#module load OpenFOAM
module load OpenFOAM-Extend/4.0
echo "Executing job commands, current working directory is `pwd`"
source $FOAM_BASH



mpiexec -np 6 MoDesFinal -parallel

